printf("Hello")
